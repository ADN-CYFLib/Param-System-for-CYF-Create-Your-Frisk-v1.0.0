Player.SetControlOverride(true)
Player.MoveToAbs(320, 155 + 90, true)
Arena.ResizeImmediate(155, 130)
